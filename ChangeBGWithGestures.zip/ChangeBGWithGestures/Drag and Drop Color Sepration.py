import cv2
import mediapipe as mp

cap = cv2.VideoCapture(0)
cap.set(3, 1280)
cap.set(4, 720)
mpHands = mp.solutions.hands
hands = mpHands.Hands()
mpDraw = mp.solutions.drawing_utils
red = (0, 0, 255)
green = (0, 255, 0)
white = (255, 255, 255)

totalCirlces = 4
centerPoints = [[120, 100], [300, 160], [80, 200], [400, 400]]
circleColors = [red, green, red, green]
positions = ['U'] * totalCirlces

inside = False
right = False
left = False

radius, color, thickness = 60, red, 20

while True:
    success, img = cap.read()
    img = cv2.flip(img, 1)
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = hands.process(imgRGB)
    multiLandMarks = results.multi_hand_landmarks

    cv2.line(img, (640, 0), (640, 720), white, 10)

    if multiLandMarks:
        handPoints = []
        for handLms in multiLandMarks:
            mpDraw.draw_landmarks(img, handLms, mpHands.HAND_CONNECTIONS)

            for idx, lm in enumerate(handLms.landmark):
                # print(idx,lm)
                h, w, c = img.shape
                cx, cy = int(lm.x * w), int(lm.y * h)
                handPoints.append((cx, cy))

        if not left and handPoints[8][0] < 340:
            left = True
            print("Left")
        if not right and handPoints[8][0] > 940:
            right = True
            print("Right")


        if handPoints[8][0] > 340 and handPoints[8][0] < 940:
            left = False
            right = False



    # print(positions)
    for point, color in zip(centerPoints, circleColors):
        cv2.circle(img, point, radius, color, thickness)

    cv2.imshow("Finger Counter", img)
    cv2.waitKey(1)









