import cv2
import cvzone
from cvzone.SelfiSegmentationModule import SelfiSegmentation
import os

cap = cv2.VideoCapture(0)
cap.set(3, 480)
cap.set(4, 640)


segmentor = SelfiSegmentation(1)
BGimages = []
for img in os.listdir("Images"):
    BGimages.append(cv2.imread(f"Images/{img}"))
imgIndex = 0

while True:
    success, img = cap.read()
    bgimage = cv2.resize(BGimages[imgIndex], (640,480))
    img2 = segmentor.removeBG(img, bgimage, threshold=0.6)
    imgStack = cvzone.stackImages([img, img2],2,1)

    cv2.imshow("Video", imgStack)

    key = cv2.waitKey(1)

    if key == ord('a'):
        if imgIndex > 0:
            imgIndex -= 1
    elif key == ord('d'):
        if imgIndex < 3:
            imgIndex += 1
